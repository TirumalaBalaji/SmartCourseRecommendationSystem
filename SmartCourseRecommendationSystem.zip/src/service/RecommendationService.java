package service;
import db.DBConnection;
import java.sql.*;
import java.util.*;
public class RecommendationService {
    public List<Integer> recommendCourses(int completedCourseId) {
        List<Integer> recommended = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT course_id FROM prerequisites WHERE prereq_id=?";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, completedCourseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                recommended.add(rs.getInt("course_id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return recommended;
    }
}