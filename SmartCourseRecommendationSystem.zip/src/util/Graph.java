package util;
import java.util.*;
public class Graph {
    private Map<Integer, List<Integer>> adjList = new HashMap<>();
    public void addEdge(int course, int prereq) {
        adjList.computeIfAbsent(prereq, k -> new ArrayList<>()).add(course);
    }
    public List<Integer> bfs(int start) {
        List<Integer> result = new ArrayList<>();
        Queue<Integer> queue = new LinkedList<>();
        Set<Integer> visited = new HashSet<>();
        queue.add(start);
        visited.add(start);
        while (!queue.isEmpty()) {
            int node = queue.poll();
            result.add(node);
            for (int neighbor : adjList.getOrDefault(node, new ArrayList<>())) {
                if (!visited.contains(neighbor)) {
                    queue.add(neighbor);
                    visited.add(neighbor);
                }
            }
        }
        return result;
    }
}