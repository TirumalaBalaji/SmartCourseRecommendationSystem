# 📘 Smart Course Recommendation System

An intelligent course recommendation system built with Java, JDBC, and MySQL. Uses data structures like Graph, Queue, Stack, HashMap, and PriorityQueue.

## Features
- User Authentication (Student/Admin)
- Course Management
- Graph-based Recommendation Engine
- Database Integration (MySQL)

## Tech Stack
- Java
- MySQL
- JDBC
- Data Structures: Graph, Queue, Stack, HashMap, PriorityQueue

## Setup
1. Clone the repo.
2. Import `sql/schema.sql` into MySQL.
3. Update DB credentials in `src/db/DBConnection.java`.
4. Compile and run `Main.java`.

## Sample Credentials
- Admin: `admin@example.com` / `admin123`
- Student: `john@example.com` / `1234`
