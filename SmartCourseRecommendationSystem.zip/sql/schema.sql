CREATE DATABASE IF NOT EXISTS course_recommendation;
USE course_recommendation;
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    password VARCHAR(100),
    role VARCHAR(20)
);
CREATE TABLE courses (
    course_id INT AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(100),
    description TEXT,
    difficulty INT
);
CREATE TABLE enrollments (
    enroll_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    course_id INT,
    status VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);
CREATE TABLE prerequisites (
    course_id INT,
    prereq_id INT,
    PRIMARY KEY(course_id, prereq_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id),
    FOREIGN KEY (prereq_id) REFERENCES courses(course_id)
);
INSERT INTO users (name, email, password, role) VALUES
('Admin', 'admin@example.com', 'admin123', 'admin'),
('John Doe', 'john@example.com', '1234', 'student');
INSERT INTO courses (course_name, description, difficulty) VALUES
('Introduction to Programming', 'Basics of programming', 1),
('Data Structures', 'Learn about data structures', 2),
('Algorithms', 'Algorithm design and analysis', 3),
('Databases', 'Introduction to SQL and databases', 2);
INSERT INTO prerequisites (course_id, prereq_id) VALUES
(2, 1),
(3, 2),
(4, 1);